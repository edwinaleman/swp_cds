<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'id7769093_wp_9eda6b4d87170f77911926b7c5ad672d' );

/** MySQL database username */
define( 'DB_USER', 'id7769093_wp_9eda6b4d87170f77911926b7c5ad672d' );

/** MySQL database password */
define( 'DB_PASSWORD', '1144d7be25cdf449a709b310fdceb1afc8bbcba7' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         ' (R^?rT~S1}N4j=m+w`;+`;{~,.1t{4pSrCUV4*i7%;jX$`@^Px6;v~T6K<G?g+Q' );
define( 'SECURE_AUTH_KEY',  'NMv$.2tX@xAgBqJ%}aGRpzCs#/u;+F$k4r4/<,TtMahRQ#>rBIYN^vE!AcCy`$C=' );
define( 'LOGGED_IN_KEY',    '|?w%CORXt,q#kD&s!.]1ao;#S%qCa|~vq`ZY=>nOhl8%X26o3$_X)W}sKq3PxR@5' );
define( 'NONCE_KEY',        '+cpXt)^j6=(~PA<dofQ[h0k|(-=~4;j*$d+BG;#JmT[vbn)UrTd%T1&~PY|l!0nv' );
define( 'AUTH_SALT',        'w+,Iv$PS-(D !>Dh>i%8u@k5MH%:ro .@`<M*y!W_+fv,#A@)TEn;V7(`-}`y*kr' );
define( 'SECURE_AUTH_SALT', 'Rp)X[Loce}vTV3&,1RVrMea@O*4^3.mo}N F)DNA| X9W0tl0uRPnQo_jx79-N{^' );
define( 'LOGGED_IN_SALT',   '~u:g}m:g@8>*!lOiQ, JregXw0h45RaB?:2Z0m]cn19dlCwAV=>A6J-iL4@FPyiM' );
define( 'NONCE_SALT',       ';Z1^JznzZ.IPY!6.4ZU7wcPVFH[t|J5Ihl([cT0v&%w?LSR!6oZW5r]pXPBrE+;I' );

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';




/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) )
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
